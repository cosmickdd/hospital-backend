# prana_ai/urls.py
